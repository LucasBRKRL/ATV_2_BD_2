import psycopg2

def updateTable(Codigo_Filme, titulo):
    try:
        connection = psycopg2.connect(user="postgres",
                     password="root",
                    host="127.0.0.1",
                     port="5432",
                     database="cinema")

        cursor = connection.cursor()

        print("Table Before updating record ")
        sql_select_query = """select * from filme where Codigo_Filme = %s"""
        cursor.execute(sql_select_query, (Codigo_Filme,))
        record = cursor.fetchone()
        print(record)

        # Fazendo o update no banco de dados!
        sql_update_query = """Update filme set Titulo = %s where Codigo_Filme = %s"""
        cursor.execute(sql_update_query, (Titulo, Codigo_Filme))
        connection.commit()
        count = cursor.rowcount
        print(count, "Record Updated successfully ")

        print("Table After updating record ")
        sql_select_query = """select * from filme where Codigo_Filme = %s"""
        cursor.execute(sql_select_query, (Codigo_Filme,))
        record = cursor.fetchone()
        print(record)

    except (Exception, psycopg2.Error) as error:
        print("Error in update operation", error)

    finally:
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")

Codigo_Filme = 2
Titulo = "Combo do fluminense"
updateTable(Codigo_Filme, Titulo)
