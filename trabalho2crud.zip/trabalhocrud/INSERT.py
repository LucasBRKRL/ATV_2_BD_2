import datetime
import psycopg2

try:
    connection = psycopg2.connect(user="postgres",
                                  password="root",
                                  host="127.0.0.1",
                                  port="5432",
                                  database="cinema")

    cursor = connection.cursor()
    # Inserindo na tabela do banco de dados
    insert_query = """ INSERT INTO filme (Codigo_Filme, titulo, genero, ano, duracao, diretor, FaixaEtaria) VALUES (%s, %s, %s, %s,%s, %s, %s)"""
    item_tuple = (1, "Aulão", "Banco de dados", 2022, 180, "reginaldo", 18)
    cursor.execute(insert_query, item_tuple)
    connection.commit()
    print("Filme inserido com sucesso!")

    insert_query = """ INSERT INTO filme (Codigo_Filme, titulo, genero, ano, duracao, diretor, FaixaEtaria) VALUES (%s, %s, %s, %s,%s, %s, %s)"""
    item_tuple = (2, "Auletas", "Banco de dados", 2022, 128, "reginaldo", 18)
    cursor.execute(insert_query, item_tuple)
    connection.commit()
    print("Filme inserido com sucesso!")

    insert_query = """ INSERT INTO filme (Codigo_Filme, titulo, genero, ano, duracao, diretor, FaixaEtaria) VALUES (%s, %s, %s, %s,%s, %s, %s)"""
    item_tuple = (3, "Teste", "PDM", 2022, 150, "reginaldo", 18)
    cursor.execute(insert_query, item_tuple)
    connection.commit()
    print("Filme inserido com sucesso!")


except (Exception, psycopg2.Error) as error:
    print("Error while connecting to PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")