import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(user="postgres",
                                  password="root",
                                  host="127.0.0.1",
                                  port="5432",
                                  database="cinema")

    cursor = connection.cursor()
    # Criar as tabelas no banco de dados
    create_table_query = '''CREATE TABLE FILME (
    Codigo_Filme INT PRIMARY KEY,
    Titulo VARCHAR(100),
    Genero VARCHAR(50),
    Ano INT,
    Duracao INT,
    Diretor VARCHAR(150),
    FaixaEtaria INT);

    CREATE TABLE CINEMA (
    Codigo_do_Cinema INTEGER NOT NULL PRIMARY KEY,
     Nome_Fantasia VARCHAR(100),
     Rua VARCHAR(100),
     Bairro VARCHAR(100),
    Cidade INT,
    Estado INT,
    Lotacao INT);
'''
    # Execute a command: this creates a new table
    cursor.execute(create_table_query)
    connection.commit()
    print("Table created successfully in PostgreSQL ")

except (Exception, Error) as error:
    print("Error while connecting to PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")
