import psycopg2
from psycopg2 import Error

try:
    # Conectar no database
    connection = psycopg2.connect(user="postgres",
                                password="root",
                                    host="127.0.0.1",
                                    port="5432",
                                    database="cinema")

        
    cursor = connection.cursor()
    # Informações do banco de dados
    print("PostgreSQL server information")
    print(connection.get_dsn_parameters(), "\n")

   

except (Exception, Error) as error:
        print("Error while connecting to PostgreSQL", error)
finally:
    if (connection):
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")